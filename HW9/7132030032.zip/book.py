class Page:
    number_of_pages = 1

    def __init__(self, body):
        self.body = body
        self.page_number = Page.number_of_pages


class Book:
    def __init__(self, author, title):
        self.author = author
        self.title = title
        self.pages = []

    def add_page(self, page: Page):
        Page.number_of_pages =+ 1
        self.pages.append(page)

    @property
    def pages_count(self):
        return len(self.pages)
