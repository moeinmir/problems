import unittest
import requests

from book import Book, Page


class TestStringMethods(unittest.TestCase):

    def test_upper_method(self):
        self.assertEqual('foo'.upper(), 'FOO')

    def test_isupper_method(self):
        self.assertTrue('FOO'.isupper())

    def test_contains(self):
        s = 'Ali is doctor'
        self.assertIn('Ali', s)
        self.assertIn('doctor', s)


class TestBookMethods(unittest.TestCase):

    def setUp(self):
        self.book = Book(author="Mohammad", title='First book')

    def test_add_page_to_book(self):
        self.assertEqual(self.book.pages_count, 0)
        page1 = Page(body='Test body 1')
        page2 = Page(body='Test body 2')
        self.book.add_page(page1)
        self.book.add_page(page2)

        self.assertEqual(self.book.pages_count, 2)

    def test_number_of_pages(self):
        page1 = Page(body='Test body 1')
        page3 = Page(body='Test body 1')
        page4 = Page(body='Test body 1')
        page5 = Page(body='Test body 1')
        page2 = Page(body='Test body 2')
        self.book.add_page(page1)

        self.assertEqual(self.book.pages_count, Page.number_of_pages)


class TestGithubApis(unittest.TestCase):

    def setUp(self):
        self.base_url = 'https://api.github.com'

    def test_initial(self):
        res = requests.get(self.base_url)

        self.assertEqual(res.status_code, 200)

    def test_invalid_url(self):
        invalid_url = self.base_url + '/tttt'
        res = requests.get(invalid_url)

        self.assertEqual(res.status_code, 404)
